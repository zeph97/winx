//+---------------------------------------------------------------------------
//
//  Microsoft Windows
//  Copyright (c) Microsoft Corporation. All rights reserved.
//
//  File:       objerror.h
//
//----------------------------------------------------------------------------

#if _MSC_VER > 1000
#pragma once
#endif

#include "winerror.h"
