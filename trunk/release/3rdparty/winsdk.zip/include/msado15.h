//-----------------------------------------------------------------------------
// File:		msado15.h
//
// Copyright:   Copyright (c) Microsoft Corporation         
//
// Contents:	Proxy for adoint.h
//
// Comments:
//
//-----------------------------------------------------------------------------

#include "adoint.h"
