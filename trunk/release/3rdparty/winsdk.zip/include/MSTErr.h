//+-------------------------------------------------------------------------
//
//  Copyright (C) Microsoft Corporation, 1991 - 1996.
//
//  Contents:  Scheduling Agent interface error definitions.
//
//--------------------------------------------------------------------------
#ifndef _MSTERR_H_
#define _MSTERR_H_
#include "winerror.h"
// Task Scheduler error codes have been moved to winerror.h
#endif // _MSTERR_H_
