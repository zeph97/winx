//+---------------------------------------------------------------------------
//
//  Microsoft Windows
//  Copyright (C) Microsoft Corporation, 1992-1999.
//
//  File:       drivinit.h
//
//----------------------------------------------------------------------------

// All items moved to wingdi.h

