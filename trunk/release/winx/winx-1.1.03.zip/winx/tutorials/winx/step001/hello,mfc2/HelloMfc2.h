// HelloMfc2.h : main header file for the HELLOMFC2 application
//

#if !defined(AFX_HELLOMFC2_H__9DE83E16_3B1D_41AE_B7DB_E10636CD80F2__INCLUDED_)
#define AFX_HELLOMFC2_H__9DE83E16_3B1D_41AE_B7DB_E10636CD80F2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

/////////////////////////////////////////////////////////////////////////////
// CHelloMfc2App:
// See HelloMfc2.cpp for the implementation of this class
//

class CHelloMfc2App : public CWinApp
{
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHelloMfc2App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HELLOMFC2_H__9DE83E16_3B1D_41AE_B7DB_E10636CD80F2__INCLUDED_)
