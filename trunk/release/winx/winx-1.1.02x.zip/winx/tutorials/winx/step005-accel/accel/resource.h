//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDC_LEFTTOP                     5
#define IDC_RIGHTTOP                    6
#define IDC_ALL                         7
#define IDD_HELLO                       101
#define IDR_MAINMENU                    102
#define IDD_ABOUT                       104
#define IDR_ACCEL                       106
#define IDC_RIGHTBOTTOM                 1000
#define IDC_LEFTBOTTOM                  1001
#define IDC_LIST1                       1002
#define IDC_TODO                        1005
#define IDC_ABOUT                       1006
#define ID_HELP_ABOUT                   40002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40003
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
