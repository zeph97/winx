//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define ID_LEFTTOP                      10
#define ID_RIGHTTOP                     11
#define ID_ALL                          12
#define IDD_HELLO                       101
#define IDR_MAINMENU                    102
#define IDD_LISTDEMO_DIALOG             102
#define IDD_ABOUT                       104
#define IDB_BITMAP1                     110
#define IDB_BITMAP2                     111
#define IDC_RIGHTBOTTOM                 1000
#define IDC_LIST1                       1000
#define ID_RIGHTBOTTOM                  1000
#define IDC_LEFTBOTTOM                  1001
#define ID_LEFTBOTTOM                   1001
#define IDC_EDIT1                       1002
#define IDC_CHECK1                      1003
#define IDC_RADIO1                      1004
#define IDC_RADIO2                      1005
#define IDC_RADIO3                      1006
#define IDC_RADIO4                      1007
#define IDC_EDIT2                       1008
#define IDC_SPIN1                       1009
#define IDC_SLIDER1                     1010
#define IDC_HOTKEY1                     1011
#define IDC_PROGRESS1                   1012
#define IDC_COMBO1                      1013
#define IDC_COMBOBOXEX1                 1014
#define IDC_IPADDRESS1                  1015
#define IDC_TREE1                       1016
#define IDC_LIST2                       1017
#define IDC_CUSTOM1                     1018
#define IDC_CUSTOM2                     1019
#define IDC_CUSTOM3                     1020
#define ID_HELP_ABOUT                   40002
#define ID_TEST                         40003
#define ID_MENUITEM40004                40004
#define ID_MENUITEM40005                40005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
