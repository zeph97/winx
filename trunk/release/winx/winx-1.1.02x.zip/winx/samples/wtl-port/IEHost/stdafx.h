// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__E0F6A7A7_66BE_4419_8130_AC9BCE746845__INCLUDED_)
#define AFX_STDAFX_H__E0F6A7A7_66BE_4419_8130_AC9BCE746845__INCLUDED_

// Change these values to use different versions
#define WINVER          0x0400
#define _WIN32_WINNT    0x0400
//#define _WIN32_IE       0x0501

#define _WTL_USE_CSTRING
#define _ATL_APARTMENT_THREADED

#include <winx/Config.h>
#include <winx.h>
#include <winx/WebBrowser.h>
#include <wtlext/BitmapButton.h>

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__E0F6A7A7_66BE_4419_8130_AC9BCE746845__INCLUDED_)
