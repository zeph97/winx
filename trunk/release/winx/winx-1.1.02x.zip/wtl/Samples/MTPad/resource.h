//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MTPad.rc
//
#define IDD_ABOUTDLG                    104
#define IDR_PRINTPREVIEWBAR             108
#define IDR_MAINFRAME                   128
#define IDR_TEXTTYPE                    129
#define IDR_CONTEXTMENU                 130
#define ID_FILE_NEW_WINDOW              32771
#define ID_EDIT_WORD_WRAP               40003
#define ID_PP_BACK                      40006
#define ID_PP_CLOSE                     40008
#define ID_PP_FORWARD                   40011
#define ID_ROW_PANE                     61403
#define ID_COL_PANE                     61404

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40013
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
