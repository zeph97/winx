/* -------------------------------------------------------------------------
// WINX: a C++ template GUI library - MOST SIMPLE BUT EFFECTIVE
// 
// This file is a part of the WINX Library.
// The use and distribution terms for this software are covered by the
// Common Public License 1.0 (http://opensource.org/licenses/cpl.php)
// which can be found in the file CPL.txt at this distribution. By using
// this software in any fashion, you are agreeing to be bound by the terms
// of this license. You must not remove this notice, or any other, from
// this software.
// 
// Module: stdext/Array.h
// Creator: xushiwei
// Email: xushiweizh@gmail.com
// Date: 2006-12-20 15:29:13
// 
// $Id: Array.h,v 1.1 2006/12/20 08:41:43 xushiwei Exp $
// -----------------------------------------------------------------------*/
#ifndef __STDEXT_ARRAY_H__
#define __STDEXT_ARRAY_H__

#ifndef __STDEXT_BASIC_H__
#include "Basic.h"
#endif

#ifndef _STDEXCEPT_
#include <stdexcept>
#endif

__NS_STD_BEGIN

// -------------------------------------------------------------------------
// class Array - see boost::array

template <class Type, UINT nElement>
class Array
{
private:
	Type m_data[nElement];
	UINT m_size;

public:
	typedef Type value_type;
	typedef UINT size_type;
	typedef ptrdiff_t difference_type;

	typedef Type& reference;
	typedef Type* iterator;

	typedef const Type& const_reference;
	typedef const Type* const_iterator;

public:
	Array() : m_size(0) {}

    void winx_call rangecheck(size_type i)
	{
        if (i >= size())
            throw std::range_error("Array<>: index out of range");
    }

	void winx_call clear()	{ m_size = 0; }

	size_type winx_call size() const		{ return m_size; }
	bool winx_call empty() const			{ return m_size == 0; }

    // direct access to data (read-only)
    const value_type* winx_call data() const { return m_data; }

	value_type* winx_call c_array()			{ return m_data; }

    iterator winx_call begin()				{ return m_data; }
    const_iterator winx_call begin() const	{ return m_data; }

    iterator winx_call end()				{ return m_data+m_size; }
    const_iterator winx_call end() const	{ return m_data+m_size; }

	// at() with range check
    reference winx_call at(size_type i)				 { rangecheck(i); return m_data[i]; }
    const_reference winx_call  at(size_type i) const { rangecheck(i); return m_data[i]; }

	reference winx_call front()				{ return (*begin()); }
	const_reference winx_call front() const	{ return (*begin()); }

	reference winx_call back()				{ return (*(end() - 1)); }
	const_reference winx_call back() const	{ return (*(end() - 1)); }

	reference winx_call operator[](size_type i)
	{
		WINX_ASSERT( i < m_size && "out of range" );
		return m_data[i];
	}

	const_reference winx_call operator[](size_type i) const 
    {     
		WINX_ASSERT( i < m_size && "out of range" );
		return m_data[i];
    }

	void winx_call push_back(const_reference val)
	{
		WINX_ASSERT(m_size < nElement);
		if (m_size < nElement)
			m_data[m_size++] = val;
	}

	void winx_call pop_back()
	{
		if (m_size)
			--m_size;
	}
};

// -------------------------------------------------------------------------
// $Log: Array.h,v $
// Revision 1.1  2006/12/20 08:41:43  xushiwei
// STL-Extension: Container(Array), Log(MultiStorage, MultiLog)
//

__NS_STD_END

#endif /* __STDEXT_ARRAY_H__ */
