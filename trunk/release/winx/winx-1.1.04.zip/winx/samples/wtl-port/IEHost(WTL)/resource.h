//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by IEHost.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDB_BACK_BTN                    202
#define IDB_FWD_BTN                     203
#define IDB_RELOAD_BTN                  204
#define IDB_STOP_BTN                    205
#define IDR_ABOUTPAGE                   206
#define IDC_IE                          1000
#define IDC_ADDRESS                     1001
#define IDC_EVENT_LIST                  1002
#define IDC_IE_STATUS                   1003
#define IDC_BACK                        1004
#define IDC_FORWARD                     1005
#define IDC_STOP                        1006
#define IDC_RELOAD                      1007
#define IDC_WAITUP                      1008
#define IDC_LOG_BEFORENAV               1009
#define IDC_LOG_NAVCOMPLETE             1010
#define IDC_IE_PLACEHOLDER              1010
#define IDC_LOG_STATUSCHG               1011
#define IDC_LOG_DOWNLOADBEGIN           1012
#define IDC_LOG_DOWNLOADEND             1013
#define IDC_LOG_CMDSTATECHG             1014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        208
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
