// HelloMfcDlg.h : header file
//

#if !defined(AFX_HELLOMFCDLG_H__104656B9_124A_4DBE_8D83_A602CFE5B85A__INCLUDED_)
#define AFX_HELLOMFCDLG_H__104656B9_124A_4DBE_8D83_A602CFE5B85A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CHelloMfcDlg dialog

class CHelloMfcDlg : public CDialog
{
// Construction
public:
	CHelloMfcDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CHelloMfcDlg)
	enum { IDD = IDD_HELLOMFC_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HELLOMFCDLG_H__104656B9_124A_4DBE_8D83_A602CFE5B85A__INCLUDED_)
